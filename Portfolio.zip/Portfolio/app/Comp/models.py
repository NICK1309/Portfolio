from django.db import models

class About1(models.Model):
    about_id = models.AutoField
    birth = models.DateField()
    web = models.CharField(max_length= 500,default = "")
    phone = models.IntegerField(default = "")
    city = models.CharField(max_length=500,default = "")
    age = models.IntegerField()
    degree = models.CharField(max_length=500,default = "")
    email = models.CharField(max_length = 200,default = "")
    freelance = models.CharField(max_length = 200,default = "")
    # pic = models.ImageField(upload_to="static/assets",default = "")
    # des = models.CharField(max_length = 4000,default = "")


class Skills(models.Model):
    technology = models.CharField(max_length= 500)
    percentage = models.IntegerField()

class Portfolio(models.Model):
    des = models.CharField(max_length= 2000)  
    img = models.ImageField(upload_to="static/assets") 

class Testimonial(models.Model):
    name = models.CharField(max_length= 2000)
    profession = models.CharField(max_length= 2000)
    photo = models.ImageField(upload_to="static/assets")

class Contact(models.Model):
    name = models.CharField(max_length=300)
    email = models.CharField(max_length=300)
    subject = models.CharField(max_length=300)
    message = models.CharField(max_length=300)



    


