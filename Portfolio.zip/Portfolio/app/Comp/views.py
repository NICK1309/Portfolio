from django.shortcuts import render
from .models import About1
from .models import Portfolio
from .models import Skills 
from math import ceil
from django.http import HttpResponse

def index(request):
    about1 = About1.objects.all()
    # print(about1)
    # n = len(About1)
    # nslides = n // 4 + ceil((n/4)-(n//4))
    params={'about1':about1}
    return render(request,"index.html",params)
# def about(request):
#     return render(request. 'about.html')    
#--------------------------------------
# def index(request):
#     skills = Skills.objects.all()
#     # print(about1)
#     # n = len(About1)
#     # nslides = n // 4 + ceil((n/4)-(n//4))
#     params={'skills':skills}
#     return render(request,"index.html",params)
# #------------------------------   
# def index(request):
#     portfolio = Portfolio.objects.all()
#     # print(about1)
#     # n = len(About1)
#     # nslides = n // 4 + ceil((n/4)-(n//4))
#     params={'portfolio':portfolio}
#     return render(request,"index.html",params) 
# def insert_data(request):if request.method == 'POST':
#         name = request.POST['name']
#         email = request.POST['email']
#         subject = request.POST['subject']
#         message = request.POST['message']
#         my = Myuser(name = name,email = email,subject = subject,message = message)
#         my.save()
#         return HttpResponse("Data Saved")
#     else:
#         return render(request,"index.html")