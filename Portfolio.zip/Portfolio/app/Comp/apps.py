from django.apps import AppConfig


class CompConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Comp'
