from django.contrib import admin
from .models import About1
from .models import Skills
from .models import Portfolio
from .models import Testimonial
from .models import Contact


# Register your models here.
admin.site.register(About1)
admin.site.register(Skills)
admin.site.register(Portfolio)
admin.site.register(Testimonial)
admin.site.register(Contact)

